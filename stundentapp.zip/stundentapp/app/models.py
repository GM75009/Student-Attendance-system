from django.db import models

# Create your models here.
class Attendance_mng(models.Model):
    studID = models.IntegerField(primary_key = True)
    day = models.CharField(max_length=50)
    date = models.DateField()
    timein = models.CharField(max_length=50)
    timeout = models.CharField(max_length=50)
    totalhours = models.IntegerField()
    deptID = models.CharField(max_length=50)

class Student(models.Model):
    name = models.CharField(max_length=40)
    address = models.CharField(max_length=120,default="Zensar")
    studID = models.IntegerField(primary_key = True)

class Percentage(models.Model):
    sname=models.CharField(max_length=50,primary_key = True)
    days=models.CharField(max_length=50)
    totalpercentage=models.CharField(max_length=50)