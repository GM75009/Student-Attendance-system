from django.shortcuts import render,redirect
from .models import Attendance_mng,Student,AppraisalMngSystem
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from django.http import HttpResponse

# Create your views here.

def createuser(request):
    if request.method == 'POST':
        usern = request.POST.get("username")
        passw = request.POST.get("password")
        a = User.objects.create_user(username = usern,password = passw,is_staff = True, is_active = True, is_superuser = True)
        a.save()
    else:
        return render(request,"adminlog.html",context={})   
    return redirect("Abhi6")  

def cont(request):
      return render(request,"linking1.html",context={})

def stud(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        address = request.POST.get("address")
        studID = request.POST.get("studID")
        b = stud(name,address,studID)
        b.save()
    else:
        return render(request,"manage_emp.html",context={})   
    return redirect("Abhi6") 

def Attendance(request):
    if request.method == 'POST':
        stud_id = request.POST.get("studID")
        d = request.POST.get("day")
        da = request.POST.get("date")
        t_in = request.POST.get("timein")
        t_out = request.POST.get("timeout")
        t_hours = request.POST.get("totalhours")
        dept_ID = request.POST.get("deptID")
        c = Attendance_mng(studID=stud_id,day=d,date=da,timein=t_in,timeout=t_out,totalhours=t_hours,deptID=dept_ID)
        c.save()
    else:
        return render(request,"asheet.html",context={})    
    return redirect("Abhi6") 

def appraisal(request):
    if request.method == 'POST':
        empid = request.POST.get("emp_ID")
        jobknow = request.POST.get("jobknowledge")
        workq = request.POST.get("workquality")
        techs = request.POST.get("techskills")
        sal = request.POST.get("salary")
        app = request.POST.get("appraise")
        d = AppraisalMngSystem(emp_ID=empid,jobknowledge=jobknow,workquality = workq,techskills=techs,salary=sal,appraise=app)
        d.save()
    else:
        return render(request,"appraisal.html",context={})       
    return redirect("Abhi6") 

def adminlogin(request):
    try:
        if request.method == 'POST':
            usern = request.POST.get("username")
            passw = request.POST.get("password")
            a = User.objects.create_user(username = usern,password = passw,is_staff = True, is_active = True, is_superuser = True)
            a = a.save()
            userObj=User.objects.get(username=usern)
            if userObj is not None:
                user1=authenticate(request,username=usern,password=passw)
            
                if user1 is not None:
                    login(request,user1)
                else:
                    return HttpResponse("auth")
            else:
                return redirect("Abhi1")
        else:
            return render(request,"loginform.html",context={})
        return redirect("Abhi6")
    except:
         return redirect("Abhi6")


def studrep(request):
    s_rep = stud.objects.all()
    #print(e_rep)
    return render(request,"studrep.html",context={"s_rep":s_rep})

def a_sheet_rep(request):
    a_rep = Attendance.objects.all()
    #print(e_rep)
    return render(request,"arep.html",context={"a_rep":a_rep})

def app_rep(request):
    app_rep = AppraisalMngSystem.objects.all()
    #print(e_rep)
    return render(request,"appreport.html",context={"app_rep":app_rep})

def list_dept(request):
    l_dept = Attendance.objects.all()
    return render(request,"deptlist.html",context={"l_dept":l_dept})

def filter_dept1(request):
    f_dept1 = Attendance.objects.filter(deptID__istartswith=1)
    if f_dept1:
         return render(request,"dept1.html",context={"f_dept1":f_dept1})
    
def filter_dept2(request):
    f_dept2 = Attendance.objects.filter(deptID__istartswith=2)
    if f_dept2:
         return render(request,"dept2.html",context={"f_dept2":f_dept2})
         
def filter_dept3(request):
    f_dept3 = Attendance.objects.filter(deptID__istartswith=3)
    if f_dept3:
         return render(request,"dept3.html",context={"f_dept3":f_dept3})

def filter_dept4(request):
    f_dept4 = Attendance.objects.filter(deptID__istartswith=4)
    if f_dept4:
         return render(request,"dept4.html",context={"f_dept4":f_dept4})
    

