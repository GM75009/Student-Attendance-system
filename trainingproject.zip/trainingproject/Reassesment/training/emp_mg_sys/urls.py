from emp_mg_sys import views
from django.urls import URLPattern, path

urlpatterns = [
    path('createadmin/',views.createuser,name="Abhi1"),
    path('studmng/',views.stud,name="Abhi2"),
    path('attendance/',views.Attendance,name="Abhi3"),
    path('appraise/',views.AppraisalMngSystem,name="Abhi4"),
    path('studrep/',views.studrep,name="Abhi5"),
    path('welcome/',views.cont,name="Abhi6"),
    path('attendancerep/',views.a_sheet_rep,name="Abhi7"),
    path('apprep/',views.app_rep,name="Abhi8"),
    path('deptlist/',views.list_dept,name="Abhi9"),
    path('ftime1/',views.filter_dept1,name="Abhi10"),
    path('ftime2/',views.filter_dept2,name="Abhi11"),
    path('ftime3/',views.filter_dept3,name="Abhi12"),
    path('ftime4/',views.filter_dept4,name="Abhi13"),
    path('adminlog/',views.adminlogin,name="Abhi14")
    
]